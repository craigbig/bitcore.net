// Copyright (c) .NET Foundation and contributors. All rights reserved.
// Licensed under the MIT license. See LICENSE file in the project root for full license information.

export type Diagnostic = {
    start: number,
    end: number,
    message: string,
    severity: number
}

